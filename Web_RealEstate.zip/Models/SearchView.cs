﻿namespace RealEstate.Models
{
    public class SearchViewModel
    {
        public string Name { get; set; }
        public int? Id { get; set; }

    }

}
